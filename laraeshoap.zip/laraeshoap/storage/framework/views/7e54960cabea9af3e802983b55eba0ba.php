<?php $__env->startSection('view_category'); ?>
    <?php if(session('deletecategory_message')): ?>
        <div class="alert alert-danger mt-3">
            <?php echo e(session('deletecategory_message')); ?>

        </div>
    <?php endif; ?>

    <div class="container mt-4">
        <h4 class="mb-3">View Categories</h4>

        <div class="card shadow-sm rounded-3">
            <div class="card-body">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-primary">
                        <tr>
                            <th style="width: 120px;">Category ID</th>
                            <th>Category Name</th>
                            <th style="width: 150px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="py-2"><?php echo e($category->id); ?></td>
                                <td class="py-2"><?php echo e($category->category); ?></td>
                                <td class="py-2">
                                    <a href="<?php echo e(route('admin.deleteCategory', $category->id)); ?>" 
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Are You Sure To deleteCategory?')">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views/admin/viewcategory.blade.php ENDPATH**/ ?>