

<?php $__env->startSection('view_product'); ?>
    <div class="container mt-4">
        <h4 class="mb-3">View Products</h4>

        <?php if(session('product_message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('product_message')); ?>

            </div>
        <?php endif; ?>

        <form method="GET" action="<?php echo e(route('admin.viewproduct')); ?>" class="mb-4">
            <div class="row g-2">
                <div class="col-md-6">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search by title or category">
                </div>
                <div class="col-md-3">
                    <select name="per_page" class="form-select" onchange="this.form.submit()">
                        <option value="5" <?php echo e(request('per_page') == 5 ? 'selected' : ''); ?>>5 per page</option>
                        <option value="10" <?php echo e(request('per_page') == 10 ? 'selected' : ''); ?>>10 per page</option>
                        <option value="20" <?php echo e(request('per_page') == 20 ? 'selected' : ''); ?>>20 per page</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-outline-secondary w-100" type="submit">Apply</button>
                </div>
            </div>
        </form>

        <div class="card shadow-sm rounded-3">
            <div class="card-body">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-primary">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Category</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->product_title); ?></td>
                                <td><?php echo e($product->product_description); ?></td>
                                <td><?php echo e($product->product_quantity); ?></td>
                                <td><?php echo e($product->product_price); ?></td>
                                <td><?php echo e($product->product_category); ?></td>
                                <td>
                                    <?php if($product->product_image): ?>
                                        <img src="<?php echo e(asset('product_images/' . $product->product_image)); ?>" width="80" height="80" class="img-thumbnail">
                                    <?php else: ?>
                                        <span class="text-muted">No image</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.editproduct', $product->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(route('admin.deleteproduct', $product->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">No products found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="mt-3">
                    <?php echo e($products->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views\admin\viewproduct.blade.php ENDPATH**/ ?>