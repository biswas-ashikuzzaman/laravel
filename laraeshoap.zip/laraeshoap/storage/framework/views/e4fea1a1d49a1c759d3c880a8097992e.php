<?php $__env->startSection('view_order'); ?>
<div class="container mt-4">
    <h4 class="mb-4 fw-bold">Order List</h4>

    <?php if(session('order_message')): ?>
        <div class="alert alert-success"><?php echo e(session('order_message')); ?></div>
    <?php endif; ?>

    <div class="table-responsive shadow-sm rounded">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>ID</th>
                    <th>Customer</th>
                    <th>Email</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Invoice</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center fw-bold"><?php echo e($order->id); ?></td>

                    <td><?php echo e($order->user->name ?? 'Unknown User'); ?></td>
                    <td><?php echo e($order->user->email ?? 'N/A'); ?></td>

                    
                    <td class="fw-bold text-success">
                        ৳<?php echo e(optional($order->product)->product_price ?? 'N/A'); ?>

                    </td>

                    
                    <td>
                        <form action="<?php echo e(route('admin.updateorderstatus', $order->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <?php
                                if ($order->status == 'Pending') {
                                    $bg = 'bg-warning text-dark';
                                } elseif ($order->status == 'Delivered') {
                                    $bg = 'bg-primary text-white';
                                } elseif ($order->status == 'Cancelled') {
                                    $bg = 'bg-danger text-white';
                                } else {
                                    $bg = 'bg-secondary text-white';
                                }
                            ?>

                            <select name="status" onchange="this.form.submit()"
                                class="form-select form-select-sm <?php echo e($bg); ?>">
                                <option value="Pending" class="text-dark" <?php echo e($order->status=='Pending' ? 'selected' : ''); ?>>
                                    Pending
                                </option>
                                <option value="Delivered" class="text-dark" <?php echo e($order->status=='Delivered' ? 'selected' : ''); ?>>
                                    Delivered
                                </option>
                                <option value="Cancelled" class="text-dark" <?php echo e($order->status=='Cancelled' ? 'selected' : ''); ?>>
                                    Cancelled
                                </option>
                            </select>
                        </form>
                    </td>

                    
                    <td class="text-center">
                        <?php if($order->payment_status == 'Paid'): ?>
                            <span class="badge bg-success px-3 py-2">Paid</span>
                        <?php elseif($order->payment_status == 'Cash on Delivery'): ?>
                            <span class="badge bg-info text-dark px-3 py-2">Cash on Delivery</span>
                        <?php else: ?>
                            <span class="badge bg-danger px-3 py-2">Unpaid</span>
                        <?php endif; ?>
                    </td>

                    
                    <td class="text-center">
                        <a href="<?php echo e(route('admin.downloadinvoice', $order->id)); ?>"
                           class="btn btn-sm btn-outline-primary">
                            Download
                        </a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views\admin\vieworders.blade.php ENDPATH**/ ?>