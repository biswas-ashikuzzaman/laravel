<?php $__env->startSection('view_order'); ?>
<div class="container mt-4">
    <h4>Order List</h4>

    <?php if(session('order_message')): ?>
        <div class="alert alert-success"><?php echo e(session('order_message')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover mt-3">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Total</th>
                <th>Status</th>
                <th>Actions</th>
                <th>Invoice</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->customer_name); ?></td>
                    <td><?php echo e($order->customer_email); ?></td>
                    <td>৳<?php echo e($order->total_price); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.updateorderstatus', $order->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <select name="status" onchange="this.form.submit()" class="form-select form-select-sm">
                                <option value="Pending" <?php echo e($order->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="Delivered" <?php echo e($order->status == 'Delivered' ? 'selected' : ''); ?>>Delivered</option>
                                <option value="Cancelled" <?php echo e($order->status == 'Cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                            </select>
                        </form>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.downloadinvoice', $order->id)); ?>" class="btn btn-sm btn-info">Download Invoice</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($orders->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views/admin/vieworders.blade.php ENDPATH**/ ?>