<?php $__env->startSection('edit_product'); ?>
    <div class="container mt-4">
        <h4 class="mb-3">Edit Product</h4>

        <form action="<?php echo e(route('admin.updateproduct', $product->id)); ?>" method="post" enctype="multipart/form-data" class="p-4 border rounded bg-light shadow-sm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="mb-3">
                <label for="product_title" class="form-label">Product Title</label>
                <input type="text" id="product_title" name="product_title" class="form-control" value="<?php echo e($product->product_title); ?>">
            </div>

            <div class="mb-3">
                <label for="product_description" class="form-label">Product Description</label>
                <textarea id="product_description" name="product_description" class="form-control"><?php echo e($product->product_description); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="product_quantity" class="form-label">Quantity</label>
                <input type="number" id="product_quantity" name="product_quantity" class="form-control" value="<?php echo e($product->product_quantity); ?>">
            </div>

            <div class="mb-3">
                <label for="product_price" class="form-label">Price</label>
                <input type="number" id="product_price" name="product_price" class="form-control" value="<?php echo e($product->product_price); ?>">
            </div>

            <div class="mb-3">
                <label for="product_category" class="form-label">Select Category</label>
                <select id="product_category" name="product_category" class="form-select">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($product->product_category == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->category); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="product_image" class="form-label">Product Image</label>
                <input type="file" id="product_image" name="product_image" class="form-control">
                <?php if($product->product_image): ?>
                    <img src="<?php echo e(asset('product_images/' . $product->product_image)); ?>" width="100" class="mt-2">
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-success">Update Product</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views/admin/editproduct.blade.php ENDPATH**/ ?>