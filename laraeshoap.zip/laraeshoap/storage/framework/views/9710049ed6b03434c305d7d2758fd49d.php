<?php $__env->startSection('index'); ?>
<!-- shop section -->

  <div class="container mt-5">
    <h3 class="mb-4">Latest Products</h3>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100" style="border-radius:10px;">
                    
                    <!-- ✅ Wrap whole card content (except button) with link -->
                    <a href="<?php echo e(route('product_details', $product->id)); ?>" style="text-decoration:none; color:inherit;">

                        <?php if($product->product_image): ?>
                            <img src="<?php echo e(asset('product_images/' . $product->product_image)); ?>" 
                                 class="card-img-top"
                                 alt="<?php echo e($product->product_title); ?>"
                                 style="height:200px; object-fit:cover;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/default.png')); ?>" 
                                 class="card-img-top"
                                 alt="No image"
                                 style="height:200px; object-fit:cover;">
                        <?php endif; ?>
                        
                        <div class="card-body text-center">
                            <h5 class="card-title"><?php echo e($product->product_title); ?></h5>
                            <p class="card-text"><?php echo e(Str::limit($product->product_description, 60)); ?></p>
                            <p class="card-text text-danger fw-bold">৳<?php echo e($product->product_price); ?></p>
                        </div>

                    </a>

                    <div class="card-footer bg-white text-center">

    <!-- Preview Button -->
    <a href="<?php echo e(route('product_details',$product->id)); ?>" 
       class="btn btn-primary me-2">👁 Preview</a> <br> <br>

    <!-- Add to Cart Button -->
    <a href="<?php echo e(route('add_to_cart',$product->id)); ?>" 
       type="button" 
       class="btn btn-success">🛒 Add to Cart</a> <br> <br>

</div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-muted">No products available.</p>
        <?php endif; ?>
    </div>
  </div>

<!-- end shop section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views\index.blade.php ENDPATH**/ ?>