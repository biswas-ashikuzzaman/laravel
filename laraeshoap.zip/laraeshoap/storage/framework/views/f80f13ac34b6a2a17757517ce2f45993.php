<?php $__env->startSection('add_category'); ?>
    <?php if(session('category_message')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(session('category_message')); ?>

        </div>
    <?php endif; ?>

    <div class="container mt-4">
        <form action="<?php echo e(route('admin.postaddcategory')); ?>" method="post" class="p-4 border rounded bg-light shadow-sm">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="category" class="form-label">Category Name</label>
                <input type="text" id="category" name="category" class="form-control" placeholder="Enter Category Name!">
            </div>

            <button type="submit" name="submit" class="btn btn-primary">Add Category</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views/admin/addcategory.blade.php ENDPATH**/ ?>