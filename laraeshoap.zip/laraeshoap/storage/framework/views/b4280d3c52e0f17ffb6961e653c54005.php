
<base href="/public">
<?php $__env->startSection('stripe_view'); ?>

<div class="container mt-5">

    <h1 class="mb-4">Online Payment Gateway. Please Insert Your Information</h1>

    <div class="row justify-content-center">
        <div class="col-md-6">

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success text-center">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <p><?php echo e(Session::get('success')); ?></p>
                </div>
            <?php endif; ?>

            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Payment Details</h4>
                </div>

                <div class="card-body">

                    <form 
                        role="form"
                        action="<?php echo e(route('stripe.post')); ?>"
                        method="post"
                        class="require-validation"
                        data-cc-on-file="false"
                        data-stripe-publishable-key="<?php echo e(env('STRIPE_KEY')); ?>"
                        id="payment-form">

                        <?php echo csrf_field(); ?>

                        <div class='form-group'>
                            <label class='control-label'>Name on Card</label>
                            <input class='form-control' type='text' required>
                        </div>

                        <div class='form-group'>
                            <label class='control-label'>Card Number</label>
                            <input autocomplete='off' class='form-control card-number' type='text' required>
                        </div>

                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label class='control-label'>CVC</label>
                                <input autocomplete='off' class='form-control card-cvc' placeholder='311' type='text' required>
                            </div>

                            <div class="col-md-4 form-group">
                                <label class='control-label'>Exp Month</label>
                                <input class='form-control card-expiry-month' placeholder='MM' type='text' required>
                            </div>

                            <div class="col-md-4 form-group">
                                <label class='control-label'>Exp Year</label>
                                <input class='form-control card-expiry-year' placeholder='YYYY' type='text' required>
                            </div>
                        </div>

                        <div class="form-group text-center mt-3">
                            <button class="btn btn-success btn-lg btn-block" type="submit">
                                Pay Now BDT(<?php echo e($price); ?>)
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views\stripe.blade.php ENDPATH**/ ?>