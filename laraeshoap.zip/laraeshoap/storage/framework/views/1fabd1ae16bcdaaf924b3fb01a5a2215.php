

<?php $__env->startSection('add_product'); ?>
    <?php if(session('product_message')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(session('product_message')); ?>

        </div>
    <?php endif; ?>

    <div class="container mt-4">
        <form action="<?php echo e(route('admin.postaddproduct')); ?>" method="post" enctype="multipart/form-data" class="p-4 border rounded bg-light shadow-sm">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="product_title" class="form-label">Product Title</label>
                <input type="text" id="product_title" name="product_title" class="form-control" placeholder="Enter Product Title"/>
            </div>

            <div class="mb-3">
                <label for="product_description" class="form-label">Product Description</label>
                <textarea id="product_description" name="product_description" class="form-control" placeholder="Product Descriptions!"></textarea>
            </div>

            <div class="mb-3">
                <label for="product_quantity" class="form-label">Quantity</label>
                <input type="number" id="product_quantity" name="product_quantity" class="form-control" placeholder="Enter Product quantity here"/>
            </div>

            <div class="mb-3">
                <label for="product_price" class="form-label">Price</label>
                <input type="number" id="product_price" name="product_price" class="form-control" placeholder="Enter Product Price here"/>
            </div>

            <div class="mb-3">
                <label for="product_category" class="form-label">Select Category</label>
                <select id="product_category" name="product_category" class="form-select">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="product_image" class="form-label">Product Image</label>
                <input type="file" id="product_image" name="product_image" class="form-control"/>
            </div>

            <button type="submit" name="submit" class="btn btn-primary">Add Product</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views\admin\addproduct.blade.php ENDPATH**/ ?>