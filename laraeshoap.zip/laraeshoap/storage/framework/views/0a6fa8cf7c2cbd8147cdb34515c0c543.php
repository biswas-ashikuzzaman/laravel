<!DOCTYPE html>
<html>
<head>
    <title>Invoice #<?php echo e($order->id); ?></title>
    <style>
        body { font-family: Arial; margin: 40px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Invoice #<?php echo e($order->id); ?></h2>
    <p><strong>Customer:</strong> <?php echo e($order->customer_name); ?></p>
    <p><strong>Email:</strong> <?php echo e($order->customer_email); ?></p>
    <p><strong>Status:</strong> <?php echo e($order->status); ?></p>

    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
           <?php
    $items = json_decode($order->order_items, true);
?>

<?php if(is_array($items)): ?>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item['title'] ?? 'N/A'); ?></td>
            <td>৳<?php echo e($item['price'] ?? 0); ?></td>
            <td><?php echo e($item['quantity'] ?? 0); ?></td>
            <td>৳<?php echo e(($item['price'] ?? 0) * ($item['quantity'] ?? 0)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <tr>
        <td colspan="4" class="text-danger">Order items are missing or invalid.</td>
    </tr>
<?php endif; ?>

        </tbody>
    </table>

    <h4>Total: ৳<?php echo e($order->total_price); ?></h4>
</body>
</html>
<?php /**PATH D:\laravel\laraeshoap\resources\views\admin\invoice.blade.php ENDPATH**/ ?>