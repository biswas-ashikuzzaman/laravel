<base href="/public">

<?php $__env->startSection('product_details'); ?>
<?php if(session('cart_message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(session('cart_message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<div class="container mt-5">
    
    
    <div class="row">
        <div class="col-md-6">
            
            <img src="<?php echo e(asset('product_images/' . $product->product_image)); ?>" class="img-fluid rounded" alt="<?php echo e($product->product_title); ?>">
        </div>
        <div class="col-md-6">
            
            
            <h2><?php echo e($product->product_title); ?></h2>
            
            
            <p><strong>Price:</strong> ৳<?php echo e(number_format($product->product_price, 0, '.', ',')); ?></p>
            
            
            <p><strong>Stock:</strong> Available</p> 

            <p>
                <strong>Rating:</strong>
                <i class="fa fa-star" style="color: gold;"></i>
                <i class="fa fa-star" style="color: gold;"></i>
                <i class="fa fa-star" style="color: gold;"></i>
                <i class="fa fa-star" style="color: gold;"></i>
                <i class="fa fa-star-o" style="color: gold;"></i>
                (4/5)
            </p>

            
            <p><?php echo e($product->product_description); ?></p>

            <div class="mt-3">
                <a href="<?php echo e(route('add_to_cart',$product->id)); ?>" type="button" class="btn btn-success">🛒 Add to Cart</a>
                <button type="button" class="btn btn-outline-danger">❤️ Add to Wishlist</button>
                 
            </div>
        </div>
    </div>
    
    <hr>

    
    <div class="row mt-5">
        <div class="col-md-8">
            <h4>📝 Reviews</h4>
            <div class="border rounded p-3 mb-2">
                <strong>John Doe</strong> 
                <span class="text-muted">(2 days ago)</span>
                <p>Great sound quality and very comfortable to wear!</p>
                
            </div>
        </div>
    </div>

    
    <div class="row mt-5">
        <div class="col-12">
            <h4>🔗 Related Products</h4>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card h-100">
                <img src="<?php echo e(asset('images/related1.jpg')); ?>" class="card-img-top" alt="Related Product 1">
                <div class="card-body">
                    <h5 class="card-title">Bluetooth Speaker</h5>
                    <p class="card-text">৳1,499</p>
                    <a href="#" class="btn btn-outline-primary btn-sm">View Details</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card h-100">
                <img src="<?php echo e(asset('images/related2.jpg')); ?>" class="card-img-top" alt="Related Product 2">
                <div class="card-body">
                    <h5 class="card-title">Noise Cancelling Earbuds</h5>
                    <p class="card-text">৳2,199</p>
                    <a href="#" class="btn btn-outline-primary btn-sm">View Details</a>
                </div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('maindesign', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\laraeshoap\resources\views\product_details.blade.php ENDPATH**/ ?>