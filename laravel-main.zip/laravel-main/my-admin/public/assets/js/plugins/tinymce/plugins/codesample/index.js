// Exports the "codesample" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/codesample')
//   ES2015:
//     import 'tinymce/plugins/codesample'
require('./plugin.js');