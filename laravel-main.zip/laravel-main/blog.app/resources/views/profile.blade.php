
<h1>This is profile page</h1>
<h2>User Profile</h2>
<p>Name: {{ $name }}</p>
<p>Email: {{ $email }}</p>

<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus earum eveniet repellat nulla quis enim corrupti maiores, unde quia non deleniti perspiciatis magnam tempora. Blanditiis nam consequuntur exercitationem aliquid explicabo eos sunt, culpa doloribus corrupti a quasi voluptatibus nisi dolor debitis, vitae deserunt temporibus ullam rem labore id tempora quae?</p>


