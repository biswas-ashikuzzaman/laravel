
    <!-- header -->
     @include('layouts.header')
     
    <!-- navbar -->
     @include('layouts.navbar')


    

    <!-- carousel -->
     @include('layouts.carousel')

   

  <!-- card -->

  <!-- ======= Popular Packages Section ======= -->
    @include('layouts.card')


    <!-- ======= Footer Section ======= -->
     @include('layouts.footer')
