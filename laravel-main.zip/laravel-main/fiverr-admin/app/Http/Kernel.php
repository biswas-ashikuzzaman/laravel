<?php
'admin' => \App\Http\Middleware\AdminMiddleware::class,
